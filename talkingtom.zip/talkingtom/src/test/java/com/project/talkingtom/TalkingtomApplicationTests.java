package com.project.talkingtom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalkingtomApplicationTests {

	@Test
	void contextLoads() {
	}

}
