package com.project.talkingtom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.talkingtom.entity.Answer;
import com.project.talkingtom.service.AnswersService;

@RestController
public class AnswersController {

	@Autowired
	AnswersService ansService;
	
	@GetMapping("/getAllAnswers")
	public List <Answer> getAllAnswers(){
		return ansService.getAllAnswersData();
	}
	
	
}
