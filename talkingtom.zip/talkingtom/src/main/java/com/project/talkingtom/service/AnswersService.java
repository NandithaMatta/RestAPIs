package com.project.talkingtom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.talkingtom.entity.Answer;
import com.project.talkingtom.repository.AnswersRepository;

@Service
public class AnswersService {
	
	@Autowired
	AnswersRepository ansRepo;
	
	public List <Answer> getAllAnswersData(){
		return ansRepo.findAll();
	}
}
