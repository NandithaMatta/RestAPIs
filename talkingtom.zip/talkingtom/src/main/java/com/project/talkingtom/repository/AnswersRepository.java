package com.project.talkingtom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.talkingtom.entity.Answer;

public interface AnswersRepository extends JpaRepository<Answer, Integer> {

	
}
