package com.project.talkingtom.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;
import com.project.talkingtom.entity.Question;
import com.project.talkingtom.repository.QuestionsRepository;

@Service
public class QuestionsService {
	
	@Autowired
	QuestionsRepository quesRepo;
	private Object delQues;
	
	public List <Question> getAllQuestionsAnswersQuery(){
		return quesRepo.findAll();
	}
	
	public List<Question> getAnswerByQuestionQuery(String q) {
		return quesRepo.findByQues(q);
	}
	
	public Question addOrUpdateQuestionsData(Question q){
		return quesRepo.save(q);
	}
	
	public Optional<Question> getQuestionAndAnswerbyIdData(int id) {
		return quesRepo.findById(id);
	}
	
	public Question deleteUserByIdData(int id) {
		delQues = null;
		delQues = quesRepo.findById(id).orElse(null);
		if(delQues != null) {
			quesRepo.deleteById(id);
		}
		return (Question) delQues;	
		
	}

	public Question createQuestionAnswerQuery(Question ques) {
		return quesRepo.save(ques);
	}

	
	public Question deleteQuestionByIdQuery(int quesId) throws Exception {
		Question deletedQuestion = null;
		try {
			deletedQuestion = quesRepo.findById(quesId).orElse(null);
			if(deletedQuestion == null) {
				throw new Exception("Question not Available");
			}else{
				quesRepo.deleteById(quesId);
			}
		}
			catch(Exception ex) {
				throw ex;
			}
			return deletedQuestion;
		}

	public Question updateQuestionAnswerQuery(Question q) {
		// TODO Auto-generated method stub
		return quesRepo.save(q);
	}

}
