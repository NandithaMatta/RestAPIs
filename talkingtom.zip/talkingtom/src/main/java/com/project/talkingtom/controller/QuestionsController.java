package com.project.talkingtom.controller;

import java.util.List;
//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.project.talkingtom.entity.Answer;
//import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;
import com.project.talkingtom.entity.Question;
import com.project.talkingtom.repository.QuestionsRepository;
import com.project.talkingtom.service.QuestionsService;

@RestController
public class QuestionsController {

	@Autowired
	QuestionsService qs;
	
	@Autowired
	QuestionsRepository qr;
	
	
	@GetMapping("/getAllQuestionsAnswers")
	public List <Question> getAllQuestionsAnswers(){
		return qs.getAllQuestionsAnswersQuery();
	}
	
	
	@GetMapping("/getAnswerByQuestion")
	public List<Question> getAnswerByQuestion(@RequestBody ObjectNode json) {
		String q = json.get("question").asText();
		System.out.println(q);
		return qs.getAnswerByQuestionQuery(q);
	}
	
	
	@PostMapping("/createQuestionAnswer")
	public Question createQuestionAnswer(@RequestBody ObjectNode json) {
		String q = json.get("question").asText();
		String a = json.get("answer").asText();
		System.out.println(q);
		System.out.println(a);
		
		Answer ans = new Answer();
		ans.setAns(a);
		Question ques = new Question();
		ques.setQues(q);
		ques.setAns(ans);
		
		return qs.createQuestionAnswerQuery(ques);
	}
	
	
	@PostMapping("/updateQuestionAnswer")
	public Question updateQuestionAnswer(@RequestBody Question q) {
		return qs.updateQuestionAnswerQuery(q);
	}
	
	
	@PostMapping("/updateQuestionAnswerById/{id}")
	public Question updateQuestionAnswerById(@PathVariable int id, @RequestBody ObjectNode json) {
		Question ques = qr.findById(id).orElse(null);
		
		String q = json.get("question").asText();
		String a = json.get("answer").asText();
		
		int ans_id = ques.getAns().getAid();
		int ques_id = ques.getQid();
		
		qr.delete(ques);
		
		Answer ans = new Answer();
		
		ans.setAns(a);
		ans.setAid(ans_id);
		Question quest = new Question();
		quest.setQid(ques_id);
		quest.setQues(q);
		quest.setAns(ans);
		
		return qs.updateQuestionAnswerQuery(quest);
	}
	

	@DeleteMapping("/deleteQuestionAnswerById/{id}")
	public Question deleteQuestionAnswerById(@PathVariable int id){
		try {
			return qs.deleteQuestionByIdQuery(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
