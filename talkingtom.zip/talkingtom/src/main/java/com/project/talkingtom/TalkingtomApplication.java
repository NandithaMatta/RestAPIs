package com.project.talkingtom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan( basePackages = {"com.project.talkingtom.entity"} )
public class TalkingtomApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalkingtomApplication.class, args);
		
	}

}
