package com.project.talkingtom.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
//import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
//import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;

@Entity
@Table
public class Question {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int qid;
	
	@Column
	private String ques;
	
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name= "fk_ans_id", referencedColumnName="aid")
	private Answer ans;

	
	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Question(int qid, String ques, Answer ans) {
		super();
		this.qid = qid;
		this.ques = ques;
		this.ans = ans;
	}


	public int getQid() {
		return qid;
	}


	public void setQid(int qid) {
		this.qid = qid;
	}


	public String getQues() {
		return ques;
	}


	public void setQues(String ques) {
		this.ques = ques;
	}


	public Answer getAns() {
		return ans;
	}


	public void setAns(Answer ans) {
		this.ans = ans;
	}


	@Override
	public String toString() {
		return "Question [qid=" + qid + ", ques=" + ques + ", ans=" + ans + "]";
	}


}
